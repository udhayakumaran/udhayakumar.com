# SINGLE INTEGRATED PROMPT — Copy & Paste to Claude Code

**Use this as a single prompt to Claude Code (or run directly) to fix the entire portfolio at once.**

---

## THE PROMPT

```
I need to fix my portfolio site (udhayakumar.com) comprehensively. Here's what needs to change:

GOAL: Move portfolio from 85% credible to 100% credible, Staff/Principal-positioned, no friction.

CRITICAL FIXES (do these first):

1. HIDE ALL TODOs
   - Find all "[TODO:" markers in the HTML
   - Replace with nothing (delete the span)
   - These appear in case studies around: ClickHouse tuning, segmentation "hardest thing," recommendations cold-start behavior
   - Sites should have NO visible TODOs after this

2. REORDER HOMEPAGE METRICS
   - Current order: Freshness → Trial adoption → Segments → Cost reduction
   - New order: Cost reduction (77.8%) → Freshness → Trial adoption → Segments
   - Reason: Cost optimization is a Staff-level signal and should lead
   - When listing cost reduction, strengthen the copy:
     OLD: "₹1.4 lakhs/month savings"
     NEW: "77.8% cost reduction (6x more efficient). Architectural judgment: workload was wrong for the database model, not a tuning problem."

3. CONSOLIDATE RESUME
   - Current: Five resume PDFs (General, Data Platform, Architecture, Founding, E-commerce)
   - New: One consolidated resume (use General as base)
   - Update /resume page to offer only one download
   - Resume structure should be:
     * Header: Udhayakumar, Senior Backend Engineer · Platform Owner · 13+ years
     * Professional Summary (4 lines): ConvertCart, data platform ownership, cost optimization, team scaling
     * Experience: ConvertCart (all roles combined: data platform, recommendations, segmentation, LLM pipeline, team leadership, infrastructure)
     * Technical Skills: Languages & Databases, Production Systems, Currently Learning
     * Independent Work: One line mentioning Affairs Map (LLM pipeline) and others
     * Education

4. FILL IN THREE CASE STUDY GAPS (these are currently [TODO] markers):

   A) DATA PLATFORM — ClickHouse Tuning Specifics
      Location: After "achieved through batched deterministic hashing"
      Add this text:
      """
      ClickHouse tuning specifics:
      - Codecs: LZ4 for hot columns (timestamps, IDs), ZSTD for medium-use (amounts, categories), Delta for numeric with small variance
      - Partitioning: (merchant_id, date) to isolate per-client backfills
      - ORDER BY: (merchant_id, date, event_id) for both segmentation filters and time-series reports
      - Materialized views: Hourly batch refresh instead of real-time (stable CPU, predictable cost)
      - Result: Sub-second responses on million-row aggregations, 1–3 second latency for typical segmentation queries
      """

   B) SEGMENTATION — "Hardest Thing" Narrative
      Location: In "What I'd Change Today" or "Key Decisions" section
      Add this text:
      """
      The hardest part: consolidating four conflicting definitions of "customer" across platforms.
      
      Shopify uses customer_id (email + name keying), Zendesk uses contact_id (email only), Loyalty uses phone number. No single ID bridges all three.
      
      Solution: Built (platform, platform_id) → canonical_customer_id dimension table. This required understanding each source's customer identification deeply—took three weeks.
      
      Once identity resolution was solid, everything else fell into place.
      
      Secondary challenge: BigQuery's scan-based billing made reporting queries expensive. Only obvious six months later when bill spiked. Migrated to ClickHouse after patterns stabilized, cutting cost 77.8%.
      
      Lesson: Identity resolution is the unglamorous hard part of multi-source systems.
      """

   C) RECOMMENDATIONS — Cold-Start Behavior
      Location: In "Key Decisions" or "Constraints" section
      Add this text:
      """
      Cold-start handling:
      - New stores: Fall back to Automated tier (precalculated, no real-time data needed)
      - New shoppers: Show Trending blocks (top 10 most-viewed in category, no shopper history required)
      - Threshold: After three interactions (clicks/views/adds), blocks become Smart-tier personalized
      
      Tradeoff: Delayed personalization (cold → Trending → Smart) vs. immediate relevance. Three-interaction threshold balanced merchant perception against data requirements.
      
      Out-of-stock handling: Status arrives ~five-minute delayed via CDC. Smart blocks filter out-of-stock on client-side post-ranking, not backend. Merchant hydrates freshness, platform handles ranking.
      """

MEDIUM-PRIORITY FIXES (do after the above):

5. ADD AFFAIRS MAP CASE STUDY (new section)
   - Insert before "Hard Problems" section
   - Title: "LLM Production Pipeline: Affairs Map"
   - Structure: Context → Problem → Constraints → Approach → Tradeoffs → Result
   - Key points to hit:
     * Context: Current-affairs knowledge base for exam prep (UPSC, SSC, Banking)
     * Problem: Manual curation doesn't scale
     * Approach: LLM annotation → deterministic entity resolution (rapidfuzz + context) → three-bucket output (CONFIDENT/AMBIGUOUS/NEW) → curator CLI → static JSON
     * Tradeoffs: 
       - LLM for annotation, deterministic for reasoning (cost: two stages, benefit: own entity resolution)
       - Hourly batch vs. real-time (cost: 1hr lag, benefit: stable cost)
       - Static JSON vs. dynamic DB (cost: no complex queries, benefit: zero latency, CDN-deployable)
     * Result: 95%+ fact extraction accuracy, 70% reduction in curation time, ₹2–4 cost per fact with full observability
   - Metrics: 5,300 lines Python, 21 entity tables, mlflow cost tracking
   - Stack: Python, FastAPI, SQLite, LLM, OpenRouter, mlflow, rapidfuzz

6. REMOVE INDEPENDENT PRODUCTS SECTION
   - Delete the entire "Independent products" section from homepage
   - If you want to mention them, add one footnote line under Skills:
     "Also shipped Affairs Map (LLM pipeline), Fruggy (Flutter, 1K+ downloads), and various integrations. Full list on request."
   - Reason: These dilute your Staff/Principal positioning; you're not a generalist shipping consumer products

7. RESTRUCTURE ABOUT PAGE
   - Current: Leads with philosophy ("I work best owning...")
   - New: Lead with proof (ConvertCart impact), then principles
   - New structure:
     * Opening: "Thirteen years backend. Five years owning ConvertCart's data platform end to end. Scaled team 4→7, served 200+ merchants, reduced costs 77.8%."
     * Move the four testimonials into this page (they're currently buried)
     * Then: "What I've learned" → three principles (Reversibility, Match storage to question, Operational simplicity) each with one sentence proof from ConvertCart
     * Closing: "Looking for Staff/Principal roles where I can own systems end to end"

8. ADD JSON-LD SCHEMA MARKUP
   - Add to <head>:
     * Person schema (name, jobTitle, workPlace, knowsAbout, email, location)
     * BreadcrumbList schema (Home → Case Studies → Resume)
   - Reason: Makes profile machine-readable for recruiter platforms (Apollo, LinkedIn Recruiter, etc.)

9. (OPTIONAL) ADD ROLE SELECTOR
   - Add role selector buttons at top: All / Staff+Principal / Founding Engineer / Backend Architect
   - Store active role in URL hash (#staff, #founding, etc.)
   - Show role-specific note for each
   - Can conditionally hide independent products section when #staff role is selected
   - Not critical but improves UX

OUTPUT & VALIDATION:
- After all edits, verify:
  * No [TODO] markers remain in HTML (grep for "TODO" should return 0)
  * "77.8%" appears early on homepage (not buried)
  * Single resume PDF exists at /resume.pdf (or /resume)
  * Affairs Map case study exists and is readable
  * Independent products section removed
  * JSON-LD schema in <head>

DELIVERABLE:
- Updated HTML file(s) ready to deploy
- Updated single resume PDF
- No TODOs, no placeholder text, 100% complete

DO NOT:
- Add fabricated metrics or claims
- Invent numbers for TODOs (fill with real answers from context above, or omit)
- Change the technical facts in existing case studies (only fill gaps, not rewrite)
- Add new case studies beyond Affairs Map
```

---

## HOW TO USE THIS

**Option 1: Claude Code**
1. Open Claude Code
2. Point it at your portfolio repo/directory
3. Paste the prompt above
4. Run

**Option 2: Manual with Claude.ai**
1. Copy the prompt above
2. Go to claude.ai
3. Paste into chat
4. Tell Claude: "I have an HTML portfolio site at udhayakumar.com. Here's the prompt for fixing it: [paste]. Fetch the live site, make all these changes, and give me the updated HTML."
5. Download the result

**Option 3: Direct CLI**
```bash
# Fetch the site first
curl -s https://udhayakumar.com > index-live.html

# Then ask Claude to process it:
cat << 'EOF' | claude --ask-follow-up
[PASTE THE PROMPT ABOVE]

Here's my current site HTML:
$(cat index-live.html)

Please apply all the fixes listed above.
EOF
```

---

## QUICK CHECKLIST

- [ ] TODOs hidden/deleted
- [ ] Metrics reordered (cost first)
- [ ] Resume consolidated to one file
- [ ] Three case study gaps filled
- [ ] Affairs Map case study added
- [ ] Independent products section removed
- [ ] About page restructured
- [ ] JSON-LD schema added
- [ ] Validate: `grep -c "TODO" index-fixed.html` returns 0
- [ ] Deployed ✓

