# Master Index — All Files & How to Use Them

**Created:** September 3, 2026  
**For:** Udhayakumar (Portfolio fix package)  
**Total files in this delivery:** 6 critical + other supporting documents

---

## 🎯 THE 6 CRITICAL FILES (Read/Use These)

### 1️⃣ **DELIVERY-SUMMARY.md** ← START HERE
**What:** Overview of everything delivered, key findings, next steps  
**Length:** 5 min read  
**Use when:** First thing—get oriented  
**Contains:**
- What you got (5 files, 3 workflows)
- Key findings summary (5 critical issues)
- Which file to read for what
- Specific answers to your questions

---

### 2️⃣ **README-START-HERE.md** ← THEN READ THIS
**What:** Navigation guide, decision tree, quick reference  
**Length:** 10 min read  
**Use when:** "Where do I go from here?"  
**Contains:**
- Three workflows (pick your time commitment)
- Which document to open based on your situation
- Answers to your questions (independent projects? timelines?)
- Final validation checklist
- Estimated times for each fix

---

### 3️⃣ **portfolio_critique.md** ← FOR DEEP UNDERSTANDING
**What:** Comprehensive devil's advocate audit (5,000+ words)  
**Length:** 30–45 min read  
**Use when:** You want to understand *why* each fix matters  
**Contains:**
- Fresh fetch of your live site
- 13 detailed findings with reasoning
- Specific problem → why it matters → what to do
- Strategic context (market, salary, positioning)
- Detailed answer: "Should I keep independent projects?"

**Skip if:** You're in a hurry (use the single prompt instead)

---

### 4️⃣ **portfolio-fix-prompt.md** ← FOR STEP-BY-STEP IMPLEMENTATION
**What:** Detailed implementation guide with CLI commands and code (1,200+ lines)  
**Length:** 4–8 hours to execute (depends on workflow)  
**Use when:** You're ready to actually make the changes  
**Contains:**
- Part 1: Discovery & setup (fetch live site, identify gaps)
- Part 2: Reorder metrics on homepage
- Part 3: Consolidate five resumes into one
- Part 4: Fill three case study gaps (with exact text)
- Part 5: Create Affairs Map case study (full content to insert)
- Part 6: Remove independent products section
- Part 7: Restructure About page (rewrite)
- Part 8: Add JSON-LD schema markup
- Part 9: Add role selector (optional)
- Part 10: Validation & deployment
- Part 11: Automated bash script (if you prefer)

**How to use:** Go through sequentially. Each part has exact CLI commands and text to use.

---

### 5️⃣ **SINGLE-PROMPT-for-Claude-Code.md** ← FOR BATCH AUTOMATION
**What:** One self-contained prompt to copy-paste into Claude Code (1,000 words)  
**Length:** 1 hour to run (Claude does the work)  
**Use when:** You want to automate all fixes in one shot  
**Contains:**
- Condensed version of portfolio-fix-prompt.md
- No explanations, just actions
- Exact text to insert
- Validation checklist

**How to use:**
1. Copy all text from this file
2. Paste into Claude Code or Claude.ai
3. Point Claude at your site (URL or HTML)
4. Run
5. Download result

---

### 6️⃣ **QUICK-REFERENCE.txt** ← WHEN YOU'RE LOST
**What:** One-page visual guide (ASCII art, decision tree)  
**Length:** 2 min glance  
**Use when:** "What should I do next?"  
**Contains:**
- Which document to open for your situation
- Decision tree (Do you have time? Understanding required?)
- Critical vs. high-priority vs. nice-to-have fixes
- Timeline estimates
- Validation checklist

---

## 📋 THE THREE WORKFLOWS

### **Workflow A: Full Understanding (4–5 hours)**
```
1. Read DELIVERY-SUMMARY.md (5 min)
2. Read README-START-HERE.md (10 min)
3. Read portfolio_critique.md (45 min)
4. Follow portfolio-fix-prompt.md step-by-step (4 hours)
5. Validate (15 min)

Total: 5 hours
Outcome: You understand every fix, can defend every decision, own the strategy
Best for: Learning, customization, future-proofing
```

### **Workflow B: Fast Track (1 hour)**
```
1. Read DELIVERY-SUMMARY.md (5 min)
2. Copy SINGLE-PROMPT-for-Claude-Code.md
3. Paste into Claude Code or Claude.ai (5 min)
4. Point Claude at your site (5 min)
5. Let Claude apply fixes (30 min)
6. Download result, spot-check (15 min)

Total: 1 hour
Outcome: Fixed portfolio, minimal thinking required
Best for: Speed, batch processing, minimal decision fatigue
```

### **Workflow C: Balanced (2 hours)**
```
1. Read DELIVERY-SUMMARY.md (5 min)
2. Read "Summary of Critical Fixes" in portfolio_critique.md (10 min)
3. Do fixes 1–3 yourself using portfolio-fix-prompt.md PARTS 1–3 (30 min)
4. Use SINGLE-PROMPT-for-Claude-Code.md for the rest (30 min)
5. Validate (15 min)

Total: 1.5–2 hours
Outcome: Critical gaps fixed today, understand key decisions, polish later
Best for: Balancing understanding + speed (RECOMMENDED FOR YOU)
```

---

## 🔴 CRITICAL FIXES (Do First, ~1 hour)

From portfolio_critique.md:

1. **Hide/delete TODO placeholders** (20 min)
   - Signals "unfinished work"
   - Costs 15–20% credibility
   - Fix location: portfolio-fix-prompt.md PART 2

2. **Reorder homepage metrics** (15 min)
   - Cost reduction (77.8%) should come first, not fourth
   - Costs 10% impact
   - Fix location: portfolio-fix-prompt.md PART 2

3. **Consolidate five resumes into one** (30 min)
   - Reduces recruiter confusion
   - Costs 5% efficiency
   - Fix location: portfolio-fix-prompt.md PART 3

**These three fix 60% of critical issues.**

---

## 🟡 HIGH-PRIORITY FIXES (Do This Week, ~3–4 hours)

4. **Fill three case study gaps** (2 hours)
   - ClickHouse tuning specifics
   - Segmentation "hardest thing" narrative
   - Recommendations cold-start behavior
   - Fix location: portfolio-fix-prompt.md PART 4

5. **Add Affairs Map case study** (2 hours)
   - Proof of production LLM + deterministic logic
   - Staff-level contemporary work
   - Fix location: portfolio-fix-prompt.md PART 5

6. **Remove independent products section** (15 min)
   - Stops diluting Staff/Principal positioning
   - Fix location: portfolio-fix-prompt.md PART 6

7. **Restructure About page** (1 hour)
   - Lead with proof (ConvertCart), then principles
   - Fix location: portfolio-fix-prompt.md PART 7

**Combined with critical: All key positioning fixed (~4–5 hours total)**

---

## 🟢 NICE-TO-HAVE FIXES (Can Defer, ~1–2 hours)

8. **Add JSON-LD schema markup** (30 min)
   - Helps recruiters find you on Apollo, LinkedIn Recruiter
   - Fix location: portfolio-fix-prompt.md PART 8

9. **Add role selector buttons** (1 hour)
   - Better UX for visitors
   - Fix location: portfolio-fix-prompt.md PART 9

10. **Improve GitHub activity refresh** (30 min)
    - Auto-update instead of static
    - Fix location: portfolio-fix-prompt.md PART 10

---

## ❓ QUICK ANSWERS

**Q: Should I keep independent projects?**  
→ Read: portfolio_critique.md section "INDEPENDENT PROJECTS"  
→ Short answer: **No. Remove them.** (Exception: Reframe Affairs Map as case study)

**Q: Which fixes matter most?**  
→ Read: portfolio_critique.md "Summary of Critical Fixes (Prioritized)"  
→ Do critical + high-priority first, nice-to-have later

**Q: How long will this take?**  
→ Read: README-START-HERE.md "Estimated time to completion"  
→ Fast path: 1 hour (let Claude do it)  
→ Full path: 8 hours (do it yourself)

**Q: Will this help me get hired?**  
→ Read: portfolio_critique.md "Expected outcome"  
→ Expected: 30–50% increase in qualified recruiter inbound

---

## 📁 FILE REFERENCE

**Critical files (use these):**
- `DELIVERY-SUMMARY.md` — Overview (read first)
- `README-START-HERE.md` — Navigation (read second)
- `portfolio_critique.md` — Full audit (for understanding)
- `portfolio-fix-prompt.md` — Step-by-step (for implementation)
- `SINGLE-PROMPT-for-Claude-Code.md` — Copy-paste (for automation)
- `QUICK-REFERENCE.txt` — Visual guide (when lost)

**Supporting files (skip these unless needed):**
- Other files in the directory are from previous work (helpful context but not essential)

---

## 🎬 YOUR NEXT STEP

**Right now (pick one):**

1. **I want to understand first** → Open `portfolio_critique.md` and read the "Executive Summary" section (10 min)

2. **I just want it fixed** → Copy `SINGLE-PROMPT-for-Claude-Code.md` text and paste into Claude Code (5 min)

3. **I want balanced** → Read `README-START-HERE.md` "Recommended Workflow" section, then pick Workflow C (10 min)

---

## ✅ VALIDATION CHECKLIST (After all fixes)

Use this to verify everything worked:

- [ ] No [TODO] markers remain (grep "TODO" returns 0)
- [ ] "77.8%" or cost metric appears high on homepage
- [ ] Single resume PDF exists at /resume
- [ ] Affairs Map case study readable
- [ ] Independent products section removed
- [ ] About page leads with proof, then principles
- [ ] Site works locally, no broken links
- [ ] Live site live verified

---

## 🏁 TIMELINE

| When | What | Time | Files |
|------|------|------|-------|
| Today | Read & understand | 30 min | DELIVERY-SUMMARY, README-START-HERE |
| This week | Do critical + high-priority fixes | 4–5 hours | portfolio-fix-prompt or SINGLE-PROMPT |
| This month | Polish + deploy | 1–2 hours | portfolio-fix-prompt PARTS 8–10 |

---

## 🎯 EXPECTED OUTCOME

After implementing all fixes:

- ✓ Credibility: 85% → 100% (no unfinished markers)
- ✓ Positioning: Clear Staff/Principal lane
- ✓ Friction: Removed (one resume)
- ✓ Contemporary skills: Visible (LLM work)
- ✓ Impact: 30–50% increase in recruiter inbound

---

**Start with DELIVERY-SUMMARY.md. Everything else flows from there.**

