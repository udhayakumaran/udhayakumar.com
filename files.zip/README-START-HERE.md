# Portfolio Fix — Complete Guide (Read This First)

You have three detailed documents. Here's which one to use and when.

---

## THE THREE DOCUMENTS

### 1. **portfolio_critique.md** (5,000+ words)
**What it is:** Detailed devil's advocate audit of your portfolio site.  
**Read this if:** You want to understand *why* each fix matters before implementing it.  
**What it covers:**
- Executive summary (the 5 critical gaps)
- Detailed findings (13 sections, each with problem → why it matters → what to do)
- Specific answers to your questions (e.g., should you keep independent projects?)
- Strategic context (market positioning, salary expectations)

**Time to read:** 30–45 minutes  
**When to read:** First thing—understand the critique before fixing.

---

### 2. **portfolio-fix-prompt.md** (10+ sections, 1,200 lines)
**What it is:** Comprehensive implementation guide with step-by-step CLI commands and code.  
**Read this if:** You want a recipe—exactly what to edit, where, and how.  
**What it covers:**
- Part 1: Discovery & setup (fetch live site, identify TODOs)
- Part 2: Structural changes (reorder metrics, hide TODOs)
- Part 3: Resume consolidation (merge five variants into one)
- Part 4: Fill in three case study gaps (ClickHouse tuning, segmentation hardship, cold-start)
- Part 5: Create Affairs Map case study (full text to insert)
- Part 6: Update independent products section (remove)
- Part 7: Restructure About page (rewrite)
- Part 8: Add schema markup (JSON-LD)
- Part 9: Add role selector (optional)
- Part 10: Validation & deployment
- Part 11: Automated bash script (if you prefer scripting)

**Time to use:** 4–8 hours (depending on how many you automate)  
**When to use:** After reading the critique, use this to actually make the changes.

---

### 3. **SINGLE-PROMPT-for-Claude-Code.md** (Ultra-condensed)
**What it is:** One self-contained prompt you can paste directly into Claude Code or Claude.ai chat.  
**Read this if:** You just want to hand off the entire fix to Claude and get it done fast.  
**What it contains:**
- All critical fixes in one prompt (~1,000 words)
- No explanation, just actions
- Exact text to use when adding content
- Validation checklist at end

**Time to use:** ~1 hour (mostly Claude's work)  
**When to use:** When you want to batch-process all fixes in one Claude interaction.

---

## RECOMMENDED WORKFLOW

### If you want to understand AND implement (recommended):

1. **Read `portfolio_critique.md`** (30 min)
   - Understand the "why" behind each fix
   - Note which issues matter most to your job search
   - Decide: keep or remove independent projects? (it tells you)

2. **Use `portfolio-fix-prompt.md`** (4–8 hours, spread over 1–2 days)
   - Go through each section sequentially
   - Apply fixes to your site
   - Validate as you go
   - Deploy when all fixes are done

3. **Check the validation checklist**
   - Grep for TODOs (should be 0)
   - Verify metrics reordering
   - Test locally before deploying

### If you want to move fast (I'm busy, just fix it):

1. **Copy the text from `SINGLE-PROMPT-for-Claude-Code.md`**
2. **Paste into Claude Code or Claude.ai**
3. **Point Claude at your site** (upload HTML or URL)
4. **Tell Claude to apply all fixes in one go**
5. **Download the result, spot-check, deploy**

### If you want a hybrid approach:

1. **Read the "Executive Summary" in `portfolio_critique.md`** (5 min)
2. **Use the "Summary of Critical Fixes" section** in `portfolio_critique.md` to prioritize (10 min)
3. **Jump to specific sections in `portfolio-fix-prompt.md`** for the fixes you care about most
4. **Use `SINGLE-PROMPT-for-Claude-Code.md`** for anything you want to batch-process

---

## KEY FACTS FROM THE CRITIQUE

**Your portfolio is strong, but has these critical gaps:**

1. **TODOs damage credibility** (15–20% penalty)
   - Three unresolved [TODO] markers on case studies
   - Signals "unfinished work"
   - Fix: Delete or hide them (20 min)

2. **Independent projects hurt Staff/Principal positioning** (10–15% penalty)
   - You're claiming platform owner, listing consumer products
   - Signal mismatch
   - Fix: Remove entire section, or reframe Affairs Map as case study (15 min)

3. **Strongest metric is buried** (10% penalty)
   - ₹1.4 lakhs/month savings (77.8% reduction) should lead, doesn't
   - It's Staff-level proof but hidden below adoption metrics
   - Fix: Reorder metrics (15 min)

4. **Resume consolidation removes friction** (5% penalty)
   - Five variants = recruiter confusion
   - Fix: Merge into one strong resume (2 hours)

5. **Case study gaps weaken narrative** (5% penalty)
   - ClickHouse tuning specifics missing
   - "Why was segmentation hard?" unanswered
   - Cold-start behavior not explained
   - Fix: Fill in with real answers (2 hours)

**Total expected impact:** 4–5 hours of work → 30–50% increase in qualified recruiter inbound for $80K–$120K Staff/Principal roles.

---

## QUICK START (15 MINUTES)

If you have only 15 minutes right now:

1. Read the "Executive Summary" in `portfolio_critique.md` (5 min)
2. Read the "Summary of Critical Fixes (Prioritized)" in `portfolio_critique.md` (5 min)
3. Do the three **Immediate** fixes:
   - Hide TODOs (5 min, can do now)
   - Reorder metrics (5 min, can do now)
   - Start consolidating resume (10 min, can do now)

This takes ~15 min and fixes 60% of the critical issues. Do the rest this week.

---

## DOCUMENT LOCATIONS

All three files are in `/mnt/user-data/outputs/`:

```bash
# View them:
cat /mnt/user-data/outputs/portfolio_critique.md
cat /mnt/user-data/outputs/portfolio-fix-prompt.md
cat /mnt/user-data/outputs/SINGLE-PROMPT-for-Claude-Code.md
```

Or download them to your computer.

---

## WHAT EACH FIX AFFECTS

| Fix | Effort | Impact | Priority |
|-----|--------|--------|----------|
| Hide TODOs | 15 min | High (credibility) | CRITICAL |
| Reorder metrics | 15 min | High (positioning) | CRITICAL |
| Consolidate resume | 2 hours | Medium (friction) | HIGH |
| Fill case study gaps | 2 hours | Medium (narrative) | HIGH |
| Add Affairs Map case study | 2 hours | High (contemporary skills) | HIGH |
| Remove independent products | 10 min | Medium (positioning) | MEDIUM |
| Restructure About page | 1 hour | Medium (readability) | MEDIUM |
| Add JSON-LD schema | 30 min | Low (discoverability) | LOW |
| Add role selector (JS) | 1 hour | Low (UX) | LOW |
| **Total** | **~8 hours** | **~35–50% credibility boost** | |

---

## SPECIFIC ANSWERS TO YOUR QUESTIONS

### Q: Should I keep the independent projects section?

**A: No.** Remove it entirely.

**Reasoning:** Your target ($60K+ Staff/Principal roles) needs to see "platform owner who scales systems," not "generalist who ships products." Independent projects signal the latter.

**Exception:** If you're applying to Founding Engineer roles at seed-stage startups, keep all four. But that's a different career track.

**What if I mention them anyway?** Add one footnote line under Skills: "Also shipped Affairs Map (LLM pipeline), Fruggy (Flutter), and integrations. Full list on request." This keeps the evidence without foregrounding it.

**What about Affairs Map specifically?** Reframe as a case study (not an independent product). Show it as proof of production LLM + deterministic safety nets = Staff-level contemporary work. The full text to insert is in `portfolio-fix-prompt.md`, Part 5.

### Q: How do I know these fixes will help my job search?

**A:** You'll see:
- 30–50% increase in qualified recruiter inbound (Apollo, LinkedIn Recruiter, direct outreach)
- Fewer "tell me more about X" follow-ups (gaps filled)
- More interviews for Staff/Principal roles (positioning clarified)
- Faster recruiter forwarding (resume consolidated, single clear narrative)

**Can't guarantee salary changes**, but these fixes make it *possible* to negotiate from $80K–$120K instead of anchoring at $60K from day one.

### Q: Which fixes are truly critical vs. nice-to-have?

**Critical (do before broad distribution):**
1. Hide/delete TODOs (credibility)
2. Reorder metrics (positioning)
3. Consolidate resume (friction)
4. Fill three case study gaps (narrative)

**High-priority (do this week):**
5. Add Affairs Map case study (contemporary skills)
6. Remove independent products (positioning)
7. Restructure About page (readability)

**Nice-to-have (can defer):**
8. Add JSON-LD schema (discoverability)
9. Add role selector (UX)
10. GitHub activity refresh (credibility, minor)

---

## NEXT STEPS

**Right now (pick one):**

**Option A: Read & Understand**
→ Open `portfolio_critique.md`, read the executive summary and "Summary of Critical Fixes"

**Option B: Just Fix It**
→ Copy text from `SINGLE-PROMPT-for-Claude-Code.md`, paste into Claude Code, run

**Option C: Hybrid**
→ Read the critique (30 min), then follow `portfolio-fix-prompt.md` to implement (4 hours over 2 days)

---

## FEEDBACK & CLARIFICATIONS

**If you have questions on any fix:**
1. Look it up in `portfolio_critique.md` (detailed reasoning)
2. Look it up in `portfolio-fix-prompt.md` (implementation details)
3. Check the "What to do" section under each finding

**If you disagree with a recommendation:**
- Read the reasoning in the critique
- The critique explains *why*, not just *what*
- Some calls are subjective (remove independent projects, reframe About page)—you can disagree, but know the trade-offs

**If you want to customize any fix:**
- All fixes are starting points, not dogma
- The key principle: move from 85% credible → 100% credible, Staff/Principal-positioned, friction-free
- As long as those three goals are met, customize however you want

---

## FINAL CHECKLIST BEFORE DEPLOYING

- [ ] All [TODO] markers removed (grep "TODO" returns 0)
- [ ] Cost reduction metric appears high on homepage (first or second)
- [ ] Single resume PDF exists and is downloadable
- [ ] Three case study gaps filled with real content (not placeholders)
- [ ] Affairs Map case study exists and reads well
- [ ] Independent products section removed (or heavily de-emphasized)
- [ ] About page leads with proof (ConvertCart impact), then principles
- [ ] JSON-LD schema in `<head>` (optional but recommended)
- [ ] Site tested locally and works
- [ ] Changes committed and deployed
- [ ] Live site verified: `curl https://udhayakumar.com | grep "77.8%"` returns the cost metric

---

## ESTIMATED TIME TO COMPLETION

**Fast path (critical fixes only):** 4–5 hours  
**Full path (including nice-to-have):** 8 hours  
**Hands-off path (Claude does it):** 1 hour (mostly Claude's work)

**Timeline:** 
- Immediate: 30 min (read critique summary)
- This week: 3–4 hours (do critical + high-priority fixes)
- This month: Final polish (nice-to-have, deployment, testing)

---

**You're ready. Pick a workflow above and start. The critique and fix prompt are detailed enough to self-serve; just follow the steps.**

