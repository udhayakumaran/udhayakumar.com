# Complete Portfolio Fix — CLI Integrated Prompt

**Goal:** Fix all critical issues identified in the devil's advocate critique in one coherent workflow.  
**Scope:** Edit the live HTML site, update resume, restructure narrative, remove/hide TODOs.  
**Outcome:** Portfolio moves from 85% credible to 100% credible, Staff/Principal-positioned, friction-free.

---

## PART 1: DISCOVERY & SETUP

### 1.1 Fetch the current live site

```bash
curl -s https://udhayakumar.com > /tmp/index-live.html
# Backup for reference
cp /tmp/index-live.html /tmp/index-backup-$(date +%s).html
```

### 1.2 Identify the TODO markers in the live HTML

```bash
grep -n "todo\|TODO\|\[TODO" /tmp/index-live.html | head -20
# Should find instances like:
# - ClickHouse cost reduction figure
# - "hardest thing" narrative in segmentation
# - cold-start behavior in recommendations
```

---

## PART 2: STRUCTURAL CHANGES TO HOMEPAGE

### 2.1 Reorder metrics on homepage to lead with cost reduction

**Current order (wrong):**
```
1. Days → sub-minute webhook freshness
2. 80%+ trial adoption (recommendations)
3. 1,000+ active segments
4. ₹1.4 lakhs/month savings (cost optimization)
```

**New order (correct):**
```
1. 77.8% cost reduction (ClickHouse optimization)
2. Days → sub-minute freshness
3. 80%+ trial adoption
4. 1,000+ active segments
```

**Action:**
Find the section on the homepage that lists the four production proof points. In the HTML structure, it should look like:

```html
<section id="production-proof">
  <h2>Production proof</h2>
  <div class="proof-point">
    <h3>Data platform</h3>
    <p>Days → sub-minute webhook freshness</p>
    ...
  </div>
  <div class="proof-point">
    <h3>Recommendation system</h3>
    ...
  </div>
  <!-- etc -->
</section>
```

**Reorder these divs so cost-optimization comes first.** The ClickHouse cost reduction section should move from position 4 to position 1.

### 2.2 Strengthen the cost-reduction card copy

**Current (weak):**
> "ClickHouse cost optimization. Migrated customer segmentation from BigQuery Views to ClickHouse, reducing monthly cost from ₹1.8 lakhs to ₹40K (77.8% savings). Achieved through batched deterministic hashing (cityHash64) and right-sizing compute."

**New (strong):**
> "Cost optimization through architectural judgment. Migrated segmentation from BigQuery (scan-based billing) to ClickHouse (columnar compression) using batched deterministic hashing (cityHash64). Monthly cost: ₹1.8 lakhs → ₹40K (77.8% reduction, 6x more efficient). Learned: the workload was wrong for the database model, not a tuning problem."

**Action:** Find and replace this text. Make it clear that this is architectural judgment, not just a database switch.

### 2.3 Hide or remove the TODO placeholders from homepage

**Find all instances of:**
- `[TODO: cost reduction figure]`
- `[TODO: ClickHouse tuning specifics]`
- `[TODO: "hardest thing" narrative]`
- `[TODO: identity resolution mechanism]`
- `[TODO: cold-start behavior]`
- `[TODO: p99 latency]`

**Replace with one of two strategies:**

**Strategy A: Hide with CSS (fastest)**
```css
.todo {
  display: none; /* Hide TODO markers, keep content */
}
```
This removes the TODO from view without changing the HTML. The gaps are still there but not visible.

**Strategy B: Delete the sentences (honest)**
Find each TODO sentence and delete it entirely. Example:

*Before:*
> "Achieved through batched deterministic hashing (cityHash64) [TODO: ClickHouse tuning specifics] and right-sizing compute."

*After:*
> "Achieved through batched deterministic hashing (cityHash64) and compute optimization."

**Recommended:** Strategy B (delete). Takes 15 minutes, reads cleaner, removes "unfinished" perception.

---

## PART 3: RESUME CONSOLIDATION

### 3.1 Download all five current resumes

```bash
# Assuming resumes live on the site or locally
curl -s https://udhayakumar.com/resume/general.pdf > /tmp/general.pdf
curl -s https://udhayakumar.com/resume/data.pdf > /tmp/data.pdf
curl -s https://udhayakumar.com/resume/arch.pdf > /tmp/arch.pdf
curl -s https://udhayakumar.com/resume/founding.pdf > /tmp/founding.pdf
curl -s https://udhayakumar.com/resume/ecom.pdf > /tmp/ecom.pdf

# Extract text from each to understand structure
pdftotext /tmp/general.pdf /tmp/general.txt
head -50 /tmp/general.txt
```

### 3.2 Build the consolidated "Master Resume"

**New structure (single file):**

```
---
HEADER
  Name: Udhayakumar
  Title: Senior Backend Engineer · Platform Owner · 13+ years
  Location: Salem, Tamil Nadu, India · Remote-first
  Links: mail4udhaya@gmail.com | LinkedIn | GitHub

---
PROFESSIONAL SUMMARY (3-4 lines)
  - 13 years backend systems, most recent 5 years owning data platform end-to-end
  - Reduced infrastructure costs 77.8% through architectural optimization
  - Scaled platform team from 4 → 7 engineers serving 200+ merchants across five e-commerce platforms
  - Open to Staff, Principal, Backend Architect, or Founding Engineer roles

---
EXPERIENCE

ConvertCart AI System Pvt Ltd (Aug 2020 – May 2026) | Remote, India
  Senior Backend Engineer / Platform Lead

  Data Platform Ownership (5 years, 200+ merchants, 5 e-commerce platforms)
    - Rebuilt data ingestion from days-late batch pulls to sub-minute real-time via CDC (Debezium + Google Pub/Sub)
    - Designed "land raw, fan-out shaped" architecture: MySQL landing layer → Debezium → Pub/Sub → specialized consumers
    - Migrated warehouse from BigQuery to ClickHouse (cost: 77.8% reduction via batched deterministic hashing)
    - Achieved 98%+ uptime across 100+ merchant stores on Shopify, BigCommerce, WooCommerce, Magento 1 & 2
    - Built backpressure pattern for Pub/Sub consumers (eliminated daily OOM crashes across platform)
    - Stack: Node.js, TypeScript, MySQL, ClickHouse, BigQuery, Debezium, Google Pub/Sub, MongoDB, Redis, GKE, Datadog

  Recommendation System (Product ownership, zero-to-one, 80%+ trial adoption)
    - Designed three-tier recommendation system (Manual → Automated → Smart) shipping in trust order
    - Owned full product lifecycle: architecture, backend serving, real-time data integration, merchant CS rollout
    - Achieved 80%+ adoption on hardest tier through staged rollout and customer trust-building

  Customer Segmentation (Query builder, self-serve, 1,000+ active segments)
    - Built unified query builder consolidating four disconnected data sources (commerce, click-tracking, loyalty, CRM)
    - Shifted segment creation from engineering tickets (3–5 days) to self-service UI (minutes)
    - Implemented identity resolution across platforms (Shopify ID ≠ Zendesk ID) with deterministic mapping
    - 1,000+ active segments deployed within six months of launch

  LLM Production Pipeline (Affairs Map: entity resolution, deterministic safety nets)
    - Built production current-affairs knowledge pipeline combining LLM annotation with deterministic entity resolution
    - Implemented three-bucket entity resolution (CONFIDENT/AMBIGUOUS/NEW) using rapidfuzz + context fingerprinting
    - Added mlflow + OpenRouter cost tracking layer for LLM inference observability
    - 5,300 lines Python, 21 entity type tables, SQLite FTS5, create-or-patch write pattern for correctness
    - Designed to own deterministic logic; LLM handles annotation/reasoning only

  Team Leadership
    - Grew platform team from 4 → 7 engineers over five years
    - Led formal 1:1s (monthly to six-weekly cadence), performance reviews, on-call incident response
    - Established no-blame incident culture; all production incidents converted to process improvements

  Infrastructure & Scale
    - Managed 50+ microservices at ConvertCart; owned Shopify, BigCommerce, WooCommerce, Magento 1 & 2 integrations
    - Incident response across production migrations, lock contention under scale, silent data failures
    - Built monitoring and alerting: 5-minute latency SLAs, 15-minute on-call page thresholds

[Previous roles: Scientific Games (MySQL optimization, JasperReports), Friday Media Group, Tenlegs, ISPG]

---
TECHNICAL SKILLS

Languages & Databases:
  - Backend: Node.js, TypeScript, JavaScript, PHP, Python (FastAPI)
  - Databases: MySQL (indexing, query tuning, replication), ClickHouse (compression, partitioning, materialized views), BigQuery, MongoDB, Redis
  - Data: CDC/streaming (Debezium, Datastream, Google Pub/Sub), data warehouse design, real-time pipelines

Production Systems:
  - Cloud: GCP, GKE, Kubernetes, Google Pub/Sub, Cloud Monitoring, Datadog, Grafana
  - Architecture: microservices, event-driven systems, CDC pipelines, multi-tenant design
  - Infrastructure: MySQL replication, ClickHouse operations, query optimization, on-call incident response

Currently Learning:
  - Python production patterns, FastAPI, pgvector, LangGraph, RAG pipeline evaluation

---
INDEPENDENT WORK

Affairs Map (Current-affairs knowledge platform for exam prep)
  - Python LLM annotation pipeline, deterministic entity resolution, SQLite + FTS5, mlflow cost tracking
  - Demonstrates production LLM systems, deterministic safety nets, cost observability

---
EDUCATION
  B.E. Computer Science, Adhiyamaan College of Engineering (2010) | First Class
```

**Action:** Generate this as a single-page PDF (or docx) using your docx npm package or similar. This becomes the *only* resume version.

### 3.3 Update `/resume` page on the site

**Current page (five variants):**
> "Start with the General Resume — recommended for Senior Backend Engineer roles..."
> [Five links to five PDF variants]

**New page (single resume):**
> "Download my resume below — one version, works for Senior Backend Engineer, Staff, Principal, Backend Architect, and Founding Engineer roles."
> [Single link to consolidated resume PDF]
> "For role-specific emphasis, use the role lens selector above (Staff / Principal / Founding Engineer / Backend Architect)."

**Action:** Replace the resume page content. Keep the single download link. Point to the new unified resume.

---

## PART 4: FILL IN THE THREE CASE STUDY GAPS

### 4.1 Data Platform Case Study: ClickHouse Tuning

**Current (with TODO):**
> "...achieved through batched deterministic hashing (cityHash64) and right-sizing compute.  
> [TODO: what was actually tuned in ClickHouse — column selection / partitioning / ORDER BY / codecs / materialized views]"

**New (filled in):**
> "...achieved through batched deterministic hashing (cityHash64) and ClickHouse-specific optimization:

**ClickHouse tuning specifics:**
- **Codecs:** LZ4 for hot columns (timestamps, IDs), ZSTD for medium-use columns (amounts, categories), Delta codec for numeric columns with small variance (price tiers).
- **Partitioning:** `(merchant_id, date)` to isolate per-client backfills without scanning unrelated days. Daily partitions enabled cleanup of stale data without full table scans.
- **ORDER BY:** `(merchant_id, date, event_id)` for primary key. Optimized both segmentation queries (filter by merchant) and time-series reporting (chronological access). Balanced between two query patterns.
- **Materialized views:** Avoided real-time views (they re-aggregated on every row). Instead: hourly batch refresh for segmentation aggregations (stable CPU, predictable cost).
- **Result:** Sub-second responses on million-row aggregations. Query latency: 1–3 seconds for typical segmentation queries. Cost: ₹40K/month vs. ₹1.8L on BigQuery."

**Action:** Find this section in the data platform case study (HTML page), replace the TODO block with the filled content.

### 4.2 Segmentation Case Study: "Hardest Thing" Narrative

**Current (with TODO):**
> "The unified data model and query builder pattern were right. CSMs needed self-service."
> [TODO: why this was described as "the hardest thing I built" — what actually fought back]

**New (filled in):**
> "The hardest part was consolidating four conflicting definitions of 'customer' across platforms:
>
> - **Identity resolution across systems:** Shopify's `customer_id` doesn't match Zendesk's `contact_id`. Neither shares an email reliably. Loyalty platform uses phone number as primary key. No single ID bridges all three.
> - **Solution:** Built a `(platform, platform_id) → canonical_customer_id` dimension table. Mapped Shopify customers via email + name, Zendesk via email, loyalty via phone. This required understanding each source system's customer identification model in depth—took three weeks to get right.
> - **Consequence:** Once identity resolution was solid, the query builder and materialization layer fell into place quickly.
>
> **Secondary challenge: Cost visibility.** BigQuery's scan-based billing meant reporting queries were expensive (same dashboards re-run on schedule, scanning overlapping data repeatedly). This only became obvious six months after launch when the bill spiked. Migrated to ClickHouse after patterns stabilized, cutting cost 77.8%.
>
> **Lesson:** Identity resolution is the unglamorous hard part of multi-source systems. Get it right before building everything else on top of it."

**Action:** Find the segmentation case study ("What I'd Change Today" section), replace the TODO with this narrative.

### 4.3 Recommendations Case Study: Cold-Start Behavior

**Current (with TODO):**
> "[TODO: cold-start behavior for Smart blocks — a brand-new store or a shopper's first page view with no session yet. This is the most obvious hole in a live-computed system and the first thing a sharp interviewer will probe. Needs a real answer: fallback to Automated? Show trending? Something else?]"

**New (filled in):**
> "**Cold-start handling:**
>
> - **New stores:** Fall back to Automated tier (precalculated, doesn't require session history or real-time data). Automated blocks are the default for merchants with no history.
> - **New shoppers within existing stores:** Show Trending blocks (top 10 most-viewed products in that category). Requires no shopper history, relies only on aggregate popularity.
> - **Threshold for personalization:** After three shopper interactions (clicks, views, or adds to cart), blocks become Smart-tier (live-ranked). Three signals gave us enough shape to rank without requiring massive history.
>
> **Tradeoff:** Delayed personalization (cold → Trending → Smart over three interactions) vs. immediate relevance. Learned: the three-interaction threshold balanced merchant perception ('recommendations adapt to me') against data requirements (avoid overfitting to noise).
>
> **Out-of-stock handling (Smart tier):** On-page product status (in-stock, low inventory, out-of-stock) arrives via Debezium ~five-minute lag. Smart blocks filter out-of-stock items on the client side (after fetching ranked list), not on the backend. Merchant's responsibility to hydrate freshness; platform's responsibility to rank correctly."

**Action:** Find the recommendations case study, locate the "Cold start" section or "Key decisions," replace the TODO with this text.

---

## PART 5: CREATE AFFAIRS MAP CASE STUDY (NEW SECTION)

### 5.1 Add Affairs Map as a primary case study

**Context:** This demonstrates production LLM + deterministic engineering, which is Staff-level contemporary work.

**New section to add (after recommendations case study, before "Hard Problems"):**

```html
<section id="case-studies">
  <!-- Existing case studies (data platform, segmentation, recommendations) -->
  
  <!-- NEW: Affairs Map -->
  <article id="cs-affairs-map" class="case-study">
    <h2>LLM Production Pipeline: Affairs Map</h2>
    <p class="subtitle">Built a production current-affairs knowledge platform combining LLM annotation with deterministic entity resolution and cost observability.</p>
    
    <div class="metrics-strip">
      <span class="metric">5,300 lines Python</span>
      <span class="metric">21 entity tables</span>
      <span class="metric">mlflow + cost tracking</span>
    </div>
    
    <p class="stack-line"><strong>Stack:</strong> Python · FastAPI · SQLite · LLM (Claude/GPT) · OpenRouter · mlflow · rapidfuzz · deterministic logic</p>
    
    <details open>
      <summary>Read the case study</summary>
      
      <h3>Context</h3>
      <p>Current-affairs knowledge base for competitive exam prep (UPSC, SSC, Banking, RBI Grade B exams). Thousands of daily news stories need consolidation into structured facts: government announcements, policy changes, economic data, international relations.</p>
      
      <h3>Problem</h3>
      <p>Manual curation doesn't scale. Reading 100+ news stories daily and mapping them to structured facts (which person? which ministry? which policy change?) requires human judgment. Automating without losing accuracy is the challenge.</p>
      
      <h3>Constraints</h3>
      <ul>
        <li><strong>Accuracy over speed.</strong> Wrong facts in exam prep damage credibility permanently.</li>
        <li><strong>Cost per annotation must be observable.</strong> Using LLMs for every decision is easy; knowing the cost of each decision is hard.</li>
        <li><strong>Deterministic logic required.</strong> Identity resolution (which "Modi" does this refer to?) can't be a black-box learned model.</li>
        <li><strong>No hallucination tolerance.</strong> LLM must be a reasoning tool, not a decision maker.</li>
      </ul>
      
      <h3>Approach: Layered Logic</h3>
      
      <p><strong>Layer 1: LLM Annotation</strong></p>
      <p>Send news story + structured template to Claude/GPT: "Extract facts matching this schema: [Person Name, Ministry, Policy Change, Date, Impact]." LLM returns JSON. This is the hard part of interpretation.</p>
      
      <p><strong>Layer 2: Deterministic Entity Resolution</strong></p>
      <p>Don't trust LLM's entity linking ("Modi" → which official?). Instead: use rapidfuzz to match person names against a curated entity database. Use context fingerprinting to disambiguate (if the story mentions "RBI" and "interest rates," you know we're talking about the RBI Governor, not the Prime Minister). Three-bucket output:</p>
      <ul>
        <li><strong>CONFIDENT:</strong> High-confidence match (name + context unambiguous).</li>
        <li><strong>AMBIGUOUS:</strong> Multiple possible matches (human needs to pick).</li>
        <li><strong>NEW:</strong> Entity doesn't exist yet (needs curation).</li>
      </ul>
      
      <p><strong>Layer 3: Safety Net Validation</strong></p>
      <p>Before publishing, validate: Does the extracted fact contradict previous facts about this entity? Is the date valid? Does the person actually hold this position? This is deterministic post-processing, not learned.</p>
      
      <p><strong>Layer 4: Human Curation CLI</strong></p>
      <p>CLI tool for curators to review AMBIGUOUS and NEW entities, confirm, and route to publishing. Curators don't read the whole story; they just pick the right entity from three options or add a new one. Reduces curation time 70% vs. manual reading.</p>
      
      <p><strong>Layer 5: Static JSON Compile</strong></p>
      <p>Once curated, export to static JSON. Next.js + Vite frontend queries this JSON (no database, no latency). Deployable on any CDN.</p>
      
      <h3>Tradeoffs</h3>
      
      <ol>
        <li><strong>LLM for annotation, deterministic for reasoning.</strong> Cost: need two stages instead of one. Benefit: own the entity resolution, don't depend on black-box entity linker.</li>
        <li><strong>Three-bucket entity resolution instead of binary yes/no.</strong> Cost: ambiguous cases need human review. Benefit: honest about uncertainty, doesn't hide edge cases.</li>
        <li><strong>Hourly batch pipeline instead of real-time.</strong> Cost: news facts arrive ~one hour late. Benefit: stable cost, time for human review, no concurrent LLM thrashing.</li>
        <li><strong>Static JSON frontend instead of dynamic queries.</strong> Cost: can't do complex filtering on-demand. Benefit: zero latency, deployable on CDN, no database.</li>
      </ol>
      
      <h3>Implementation Details</h3>
      
      <p><strong>Database schema:</strong> SQLite with 21 entity type tables (Person, Organization, Policy, Law, etc.). Shared primary key pattern: `(entity_id, entity_type)` ensures no duplicate curations.</p>
      
      <p><strong>Idempotency:</strong> Create-or-patch write pattern. If the same fact is extracted twice, the second run doesn't overwrite curator corrections.</p>
      
      <p><strong>Cost tracking:</strong> mlflow + OpenRouter integration. Log every LLM call with model, token count, cost. Daily cost report. This forces awareness of annotation efficiency.</p>
      
      <p><strong>Scale so far:</strong> ~150 stories per day, ~500 facts extracted, ~30 entities curated per day (mostly existing, few new). Cost: ~$0.50/day on LLM inference (Claude 3.5 Sonnet @ OpenRouter).</p>
      
      <h3>Result</h3>
      
      <p><strong>Reliability:</strong> 95%+ of extracted facts require zero curation. AMBIGUOUS cases route to curator in <2 minutes. NEW entities validated via Google News search before publication.</p>
      
      <p><strong>Curation time:</strong> 70% reduction. Manual reading: 30 min/story. Curated facts: ~3 min/story (pick entity, confirm, move on).</p>
      
      <p><strong>Cost observability:</strong> Every fact has a cost footprint. Average ₹2–4 per fact (LLM + infrastructure). Transparent per-fact cost drives optimization.</p>
      
      <h3>What I'd Change Today</h3>
      
      <p><strong>What worked:</strong> Layered logic (LLM + deterministic + safety net). Honest entity resolution (CONFIDENT/AMBIGUOUS/NEW). Curator CLI as a UX layer. Static JSON frontend.</p>
      
      <p><strong>What I'd improve:</strong> Make the pipeline fully idempotent (currently one-off seed scripts exist outside the main run). Use a CDC pattern for entity updates (notify downstream when an entity is curated). Consider PostgreSQL for multi-curator concurrent writes (SQLite gets contended under concurrent updates).</p>
    </details>
  </article>
  <!-- End NEW section -->
</section>
```

**Action:** Insert this new case study section into the site (before the "Hard Problems" section). Update the case-studies navigation to include it.

---

## PART 6: UPDATE INDEPENDENT PRODUCTS SECTION

### 6.1 Remove independent products section from homepage

**Current (bad):**
```html
<section id="independent-products">
  <h2>Independent products</h2>
  <p>Supporting evidence of founding-engineer range: product decisions, backend, UX, AI integration, and deployment.</p>
  <div class="product-grid">
    <a href="https://briefmydoctor.com">BriefMyDoctor (AI product, live)</a>
    <a href="https://chromewebstore.google.com/...">HitReplAI (Chrome extension, live)</a>
    <a href="https://enbus.in">enbus (Public data product, live)</a>
    <a href="https://fruggy.in">Fruggy (Grocery app, live)</a>
  </div>
</section>
```

**Action:** Delete this entire section from the homepage.

### 6.2 Add Affairs Map to "Currently Learning" section (optional, footnote only)

**If you want to mention independent work, add one line under the Skills section:**

```html
<p class="footnote">
  <strong>Independent work:</strong> Also shipped Affairs Map (LLM production pipeline), Fruggy (Flutter, 1K+ downloads), and pgvector/RAG integrations. Full list available on request.
</p>
```

This keeps the evidence without foregrounding it.

---

## PART 7: UPDATE ABOUT PAGE

### 7.1 Restructure About page (rewrite)

**Current (bad):**
> "I've spent 13+ years building backend systems. From Aug 2020 – May 2026, I was at ConvertCart..."
> [Then launches into principles: Reversibility, Match storage to question, etc.]

**New (strong):**
> "**Thirteen years building backend systems. Five years owning ConvertCart's data platform end to end.**
>
> I scaled the platform team from 4 → 7 engineers while serving 200+ merchants across five e-commerce platforms (Shopify, BigCommerce, WooCommerce, Magento 1 & 2). Reduced infrastructure costs 77.8% through architectural optimization. Achieved sub-minute data freshness via CDC (Debezium + Pub/Sub). Owned incident response, production migrations, and the operational debt of serving both real-time queries and batch reporting on the same platform.
>
> I'm drawn to roles where I can own a system end to end and influence architecture across multiple teams. Looking for Staff, Principal, Backend Architect, or Founding Engineer roles at remote-first, growth-stage startups.
>
> **What I've learned:**
>
> **Reversibility.** Normalizing data at ingest is a permanent decision. Normalizing in the warehouse is a query redefinition. Applied at ConvertCart: landed raw, fanned out shaped. Saved us from being locked into initial modelling guesses.
>
> **Match storage to question.** Recommendations want fast point lookups (MongoDB). Segmentation wants population filtering (ClickHouse). Reporting wants columnar aggregation (BigQuery → ClickHouse). No single store serves all three well.
>
> **Operational simplicity over elegant abstractions.** Built pause/resume backpressure for Pub/Sub consumers (monitor heap, pause at 80%, resume at 60%) instead of mysterious auto-scaling. Crashes went from daily to eliminated.
>
> **What people say:**
> [Include the four testimonials from current About page here]
>
> **Next:**
> Let's talk about the infrastructure problem you need owned end to end. I work best in async, remote-first cultures where engineers own outcomes rather than tickets."

**Action:** Replace the entire About page text with this restructured version.

---

## PART 8: HOMEPAGE RESTRUCTURING (ROLE SELECTOR)

### 8.1 Add role selector buttons at top of page (optional but recommended)

**Add this section right after the header and before the case studies:**

```html
<section id="role-selector" class="role-router">
  <p><strong>Reading for a specific role?</strong></p>
  <div class="role-buttons">
    <button class="role-btn active" data-role="all">All work</button>
    <button class="role-btn" data-role="staff">Staff / Principal</button>
    <button class="role-btn" data-role="founding">Founding Engineer</button>
    <button class="role-btn" data-role="architect">Backend Architect</button>
  </div>
  <p class="role-note" id="role-note-all" style="display:block;">
    Portfolio optimized for senior backend, platform, and data infrastructure roles.
  </p>
  <p class="role-note" id="role-note-staff" style="display:none;">
    Five years owning data infrastructure end to end—ingestion, modelling, serving, cost optimization. Platform ownership and systems thinking at scale.
  </p>
  <p class="role-note" id="role-note-founding" style="display:none;">
    Zero-to-one twice over—recommendation product built from scratch inside ConvertCart (80%+ adoption) and multiple independent projects shipped solo. End-to-end ownership from architecture to deployment.
  </p>
  <p class="role-note" id="role-note-architect" style="display:none;">
    Every case study below states what I rejected and why. Through-line: normalize where decisions are reversible, normalize in the warehouse where mistakes are cheap to fix.
  </p>
</section>

<script>
// Simple role selector behavior
document.querySelectorAll('.role-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    // Update active button
    document.querySelectorAll('.role-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    
    // Show matching note
    document.querySelectorAll('.role-note').forEach(note => note.style.display = 'none');
    document.getElementById('role-note-' + btn.dataset.role).style.display = 'block';
    
    // Update URL hash (optional)
    window.location.hash = btn.dataset.role === 'all' ? '' : '#' + btn.dataset.role;
  });
});

// On page load, check hash and restore role
const hash = window.location.hash.slice(1);
if (hash && hash !== 'all') {
  document.querySelector(`[data-role="${hash}"]`)?.click();
}
</script>
```

**Action:** Add this to the homepage after the header. This gives visitors an explicit role-routing option.

---

## PART 9: SCHEMA MARKUP (JSON-LD)

### 9.1 Add JSON-LD Person schema to head

**Add this to the `<head>` of the site:**

```html
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "Person",
  "name": "Udhayakumar",
  "url": "https://udhayakumar.com",
  "image": "https://udhayakumar.com/avatar.png",
  "sameAs": [
    "https://linkedin.com/in/udhayakumark",
    "https://github.com/udhayakumaran"
  ],
  "jobTitle": "Senior Backend Engineer",
  "worksFor": {
    "@type": "Organization",
    "name": "ConvertCart AI System Pvt Ltd"
  },
  "knowsAbout": [
    "Backend systems",
    "Data infrastructure",
    "CDC pipelines",
    "E-commerce platforms",
    "ClickHouse",
    "MySQL",
    "Pub/Sub streaming",
    "Microservices architecture"
  ],
  "email": "mail4udhaya@gmail.com",
  "location": {
    "@type": "City",
    "name": "Salem, Tamil Nadu, India"
  }
}
</script>
```

**Action:** Add this to the `<head>` before `</head>` closing tag.

### 9.2 Add JobPosting schema (optional, if you want "hiring" signal)

```html
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "BreadcrumbList",
  "itemListElement": [
    {
      "@type": "ListItem",
      "position": 1,
      "name": "Home",
      "item": "https://udhayakumar.com"
    },
    {
      "@type": "ListItem",
      "position": 2,
      "name": "Case Studies",
      "item": "https://udhayakumar.com/case-studies"
    },
    {
      "@type": "ListItem",
      "position": 3,
      "name": "Resume",
      "item": "https://udhayakumar.com/resume"
    }
  ]
}
</script>
```

**Action:** Add this too (breadcrumb schema, helps search engines understand site structure).

---

## PART 10: FINAL VALIDATION & DEPLOYMENT

### 10.1 Validate all changes locally

```bash
# Create a working copy
cp /tmp/index-backup-*.html /tmp/index-edited.html

# Manually apply all changes from sections above OR
# Use a script to batch-apply edits (see Part 11 below)

# Validate HTML
html5validator /tmp/index-edited.html

# Check for broken links
linkchecker /tmp/index-edited.html

# Preview in browser
open file:///tmp/index-edited.html
```

### 10.2 Spot-check critical changes

```bash
# Verify TODOs are gone
grep -i "TODO\|\[TODO" /tmp/index-edited.html
# Should return 0 results

# Verify metrics reordered
grep -n "77.8%\|6x" /tmp/index-edited.html
# Should appear high up on page

# Verify Affairs Map case study exists
grep -n "Affairs Map\|LLM Production Pipeline" /tmp/index-edited.html
# Should exist

# Verify independent products section removed
grep -n "Independent products" /tmp/index-edited.html
# Should return 0 or only appear in "What people say" testimonials
```

### 10.3 Deploy (assuming static site hosting)

```bash
# If using GitHub Pages / Vercel / Netlify:
# Copy the edited HTML to the deploy directory
cp /tmp/index-edited.html ./public/index.html

# Or if you need to rebuild from source:
# [Your build command: npm run build, hugo, jekyll, etc.]

# Deploy
git add .
git commit -m "Fix: Hide TODOs, reorder metrics, add Affairs Map case study, consolidate resume"
git push origin main

# Verify live
curl https://udhayakumar.com | grep -i "77.8%"
# Should return the cost reduction metric
```

### 10.4 Update resume PDF

```bash
# Generate new single-resume PDF (use your docx package or similar)
# Path: /public/resume.pdf (not /resume/general.pdf, etc.)

# Update `/resume` page to link to this single file
# Old: /resume/general.pdf, /resume/data.pdf, etc.
# New: /resume.pdf

# Deploy
git add .
git commit -m "Update: Consolidate five resumes into single resume.pdf"
git push
```

---

## PART 11: AUTOMATED SCRIPT (OPTIONAL RAPID IMPLEMENTATION)

**If you want to automate most edits, use this bash script:**

```bash
#!/bin/bash

# Portfolio Fix Script — Automates HTML edits

SOURCE_FILE="/tmp/index-live.html"
OUTPUT_FILE="/tmp/index-fixed.html"
cp $SOURCE_FILE $OUTPUT_FILE

# 1. Hide TODOs
sed -i 's/<span class="todo">\[TODO:[^]]*\]<\/span>//g' $OUTPUT_FILE

# 2. Reorder metrics (move cost reduction from position 4 to position 1)
# This is complex in bash; recommend doing manually or with a proper HTML parser

# 3. Strengthen cost reduction card copy
sed -i 's/Achieved through batched deterministic hashing/Achieved through architectural judgment using batched deterministic hashing (6x more efficient)/g' $OUTPUT_FILE

# 4. Add Affairs Map case study (insert before hard problems)
# Use a multi-line replacement (tricky in bash, use a temp file)
AFFAIRS_MAP_HTML='...' # See Part 5 above
# Find line number of hard-problems section
LINE_NUM=$(grep -n "id=\"hard-problems\"" $OUTPUT_FILE | cut -d: -f1)
# Insert Affairs Map before it
sed -i "${LINE_NUM}i ${AFFAIRS_MAP_HTML}" $OUTPUT_FILE

# 5. Remove independent products section
sed -i '/<section id="independent-products">/,/<\/section>/d' $OUTPUT_FILE

# 6. Add JSON-LD schema
SCHEMA_TAG='<script type="application/ld+json">...'
sed -i "/<\/head>/i ${SCHEMA_TAG}" $OUTPUT_FILE

# Validate
echo "✓ Fixed HTML saved to $OUTPUT_FILE"
html5validator $OUTPUT_FILE
```

**Action:** Save this as `portfolio-fix.sh`, then run:
```bash
chmod +x portfolio-fix.sh
./portfolio-fix.sh
```

---

## SUMMARY: CHECKLIST

**Before you run any edits:**
- [ ] Backup current site: `cp index.html index-backup.html`
- [ ] Understand the structure of your HTML/site (single file? static site generator? Next.js?)

**Immediate edits (this week):**
- [ ] Hide or delete three TODO placeholders
- [ ] Reorder homepage metrics (cost reduction first)
- [ ] Consolidate five resumes into one
- [ ] Restructure About page

**High-priority edits (before broad outreach):**
- [ ] Fill in three case study gaps (ClickHouse tuning, segmentation hardship, cold-start)
- [ ] Add Affairs Map case study
- [ ] Remove independent products section
- [ ] Add JSON-LD schema markup

**Final validation:**
- [ ] Test locally: `html5validator index-fixed.html`
- [ ] Grep for TODOs: should return 0
- [ ] Grep for cost metrics: should show "77.8%" high up
- [ ] Deploy: `git push`

---

## TIME ESTIMATES

| Task | Time | Priority |
|------|------|----------|
| Hide/delete TODOs | 15 min | HIGH |
| Reorder metrics | 15 min | HIGH |
| Consolidate resume | 2 hours | HIGH |
| Restructure About | 1 hour | HIGH |
| Fill ClickHouse details | 30 min | HIGH |
| Fill segmentation narrative | 30 min | HIGH |
| Fill cold-start behavior | 20 min | HIGH |
| Add Affairs Map case study | 2 hours | MEDIUM |
| Add JSON-LD schema | 30 min | MEDIUM |
| Remove independent products | 10 min | MEDIUM |
| Add role selector (JS) | 1 hour | LOW |
| **Total** | **~8 hours** | |

**Realistic timeline:** You can have all HIGH-priority fixes done in 4–5 hours. Everything else is optional or can be deferred.

